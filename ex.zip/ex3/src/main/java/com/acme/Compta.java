package com.acme;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.util.StringUtils;

public class Compta {

	public static void main(String[] args) throws Exception {
		List<String> lines = Files.readAllLines(Paths.get(""));
		List<String> noVat = List.of("HOTEL", "AVION","PARKING", "PEAGE");
		for (String line : lines) {
			String[] cols =  line.split(";");
			String label = cols[4];
			if(!noVat.stream().anyMatch(x->label.contains(x))) {
				String[] vatCols = new String[9];
				vatCols[0] = cols[0];
				vatCols[1] = cols[0];
				vatCols[2] = "445660";
				vatCols[3] = "";
				vatCols[4] = "TVA - "+cols[4];
				if(StringUtils.hasText(cols[5])) {
					if(cols[4].contains("TAXI") || cols[4].contains("METRO") || cols[4].contains("TRAIN") || cols[4].contains("BATEAU")) {
						vatCols[5] =  String.valueOf(Double.parseDouble(cols[5])*0.2);				
					}
				}
				if(StringUtils.hasText(cols[6])) {
					if(cols[4].contains("TAXI") || cols[4].contains("METRO") || cols[4].contains("TRAIN") || cols[4].contains("BATEAU")) {
						vatCols[6] =  String.valueOf(Double.parseDouble(cols[5])*0.2);			
					}
				}
				vatCols[6] = StringUtils.hasText(cols[6]) ? String.valueOf(Double.parseDouble(cols[6])*0.2) : "";
				String vatLine=Stream.of(vatCols).collect(Collectors.joining(","));
			}
			String[] bankCols = new String[9];
			String banLine=Stream.of(bankCols).collect(Collectors.joining(","));
		}
	}
}
