package com.acme.ex3.business.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.acme.common.business.CommandHandler;
import com.acme.common.persistence.ObjectStore;
import com.acme.common.persistence.Results;
import com.acme.common.service.AbstractCommand;
import com.acme.ex3.model.entity.Book;
import com.acme.ex3.service.command.FindBookCommand;

public class FindBookCommandHandler implements CommandHandler {

    private ObjectStore objectStore;

    @Override
    public void handle(AbstractCommand command, HandlingContext handlingContext) {
        if (!(command instanceof FindBookCommand)) {
            return;
        }
        FindBookCommand cmd = (FindBookCommand) command;
        if (cmd.getId() != null) {
            Optional<Book> _book = this.objectStore.getById(Book.class, cmd.getId(), b -> b.getComments());
            _book.ifPresent(b -> cmd.setSingleResult(b));
        }
        else{
            String title = cmd.getFilter().getTitle();
            String authorName = cmd.getFilter().getAuthorName();

            String query = "select b from Book b join b.author a ";
            query += "where (:title is null or b.title like :title) and (:author is null or a.lastname like :author)";
            Map<String, Object> args =new HashMap<>();
            args.put("author", authorName);
            args.put("title", title);

            Results<Book> results = this.objectStore.findMany(Book.class, query, args);

            cmd.setMultipleResults(results);
        }
    }
}
